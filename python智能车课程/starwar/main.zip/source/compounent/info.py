import pygame
from .. import constant as C
import source.states.level as level

pygame.font.init()


# 传入 某一状态state 所需要的文字信息
class information():
    def __init__(self, state):
        self.state = state
        self.cre_state_label()
        self.cre_conslabel()

    # 可得到所需字体的图片形式
    def cre_label(self, label, size=40):
        font = pygame.font.SysFont(C.FONT, size)
        label_image = font.render(label, 1, C.COLOUR)
        return label_image

    # 仅某一状态所显示的文字信息
    def cre_state_label(self):
        self.main_label = []
        self.level1_label = []
        self.level2_label = []

        # 菜单栏呈现文字
        if self.state == 'Mainmenu':
            self.main_label.append(((self.cre_label('player 1', int((C.SCREEN_W / 800) * 40))),
                                    ((C.SCREEN_W / 800) * 380, (C.SCREEN_W / 800) * 240)))
            self.main_label.append(((self.cre_label('player 2', int((C.SCREEN_W / 800) * 40))),
                                    ((C.SCREEN_W / 800) * 380, (C.SCREEN_W / 800) * 300)))
            self.main_label.append(((self.cre_label('setting', int((C.SCREEN_W / 800) * 40))),
                                    ((C.SCREEN_W / 800) * 650, (C.SCREEN_W / 800) * 550)))


    # 始终显示的文字信息
    def cre_conslabel(self):
        pass

    # 更新页面
    def update(self, p1b, p2b, p1p, p2p):
        if self.state == 'Level':
            self.level1_label.clear()
            self.level1_label.append(((self.cre_label('player 1 blood : {}'.format(p1b), int((C.SCREEN_W / 800) * 20))),
                                      ((C.SCREEN_W / 800) * 100, (C.SCREEN_W / 800) * 50)))
            self.level1_label.append(((self.cre_label('player 2 blood : {}'.format(p2b), int((C.SCREEN_W / 800) * 20))),
                                      ((C.SCREEN_W / 800) * 600, (C.SCREEN_W / 800) * 50)))
            self.level1_label.append(
                ((self.cre_label('power : {}'.format(p1p), int((C.SCREEN_W / 800) * 20))),
                 ((C.SCREEN_W / 800) * 120, (C.SCREEN_W / 800) * 70)))
            self.level1_label.append(
                ((self.cre_label('power : {}'.format(p2p), int((C.SCREEN_W / 800) * 20))),
                 ((C.SCREEN_W / 800) * 620, (C.SCREEN_W / 800) * 70)))
            self.level1_label.append(
                ((self.cre_label('Level 1', int((C.SCREEN_W / 800) * 40))),
                 ((C.SCREEN_W / 800) * 340, (C.SCREEN_W / 800) * 20)))
        elif self.state == 'level2':
            self.level2_label.clear()
            self.level2_label.append(((self.cre_label('player 1 blood : {}'.format(p1b), int((C.SCREEN_W / 800) * 20))),
                                      ((C.SCREEN_W / 800) * 100, (C.SCREEN_W / 800) * 50)))
            self.level2_label.append(((self.cre_label('player 2 blood : {}'.format(p2b), int((C.SCREEN_W / 800) * 20))),
                                      ((C.SCREEN_W / 800) * 600, (C.SCREEN_W / 800) * 50)))
            self.level2_label.append(
                ((self.cre_label('power : {}'.format(p1p), int((C.SCREEN_W / 800) * 20))),
                 ((C.SCREEN_W / 800) * 120, (C.SCREEN_W / 800) * 70)))
            self.level2_label.append(
                ((self.cre_label('power : {}'.format(p2p), int((C.SCREEN_W / 800) * 20))),
                 ((C.SCREEN_W / 800) * 620, (C.SCREEN_W / 800) * 70)))
            self.level2_label.append(
                ((self.cre_label('Level 2', int((C.SCREEN_W / 800) * 40))),
                 ((C.SCREEN_W / 800) * 340, (C.SCREEN_W / 800) * 20)))


    # 所需写的文字
    def draw(self, surface):
        if self.state == 'Mainmenu':
            surface.blit(self.cre_label('SPACE WAR', size=int((C.SCREEN_W / 800) * 80)),
                         ((C.SCREEN_W / 800) * 220, (C.SCREEN_W / 800) * 20))  # 游戏主标题
            for label in self.main_label:
                surface.blit(label[0], label[1])

        if self.state == 'Load':
            surface.blit(self.cre_label('Loading...', size=int((C.SCREEN_W / 800) * 120)),
                         ((C.SCREEN_W / 800) * 220, (C.SCREEN_W / 800) * 200))

        if self.state == 'Level':
            for label in self.level1_label:
                surface.blit(label[0], label[1])

        if self.state == 'Level2':
            for label in self.level2_label:
                surface.blit(label[0], label[1])
