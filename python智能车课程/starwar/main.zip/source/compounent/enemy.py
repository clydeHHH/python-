# 小怪 boss
from tkinter import E
import pygame
import random
from .. import constant as C
from .. import setup, tools


class Enemy(pygame.sprite.Sprite):
    def __init__(self, name):
        pygame.sprite.Sprite.__init__(self)
        self.name = name
        self.load_image()
        self.rect = [random.randint(200, 1100), random.randint(100, 800)]  # 怪物初始位置随机
        self.state = random.randint(0, 3)  # 怪物转向信息
        self.step = 5  # 怪物移动速度
        # print(type(self.rect))

    def load_image(self):  # 加载怪物图片
        if self.name == 'E1':
            self.image = pygame.transform.scale(tools.GRAPHICS[C.E1], (50, 50))
        elif self.name == 'E2':
            self.image = pygame.transform.scale(tools.GRAPHICS[C.E2], (50, 50))
        elif self.name == 'E3':
            self.image = pygame.transform.scale(tools.GRAPHICS[C.E3], (50, 50))
        elif self.name == 'Boss':
            self.image = pygame.transform.scale(tools.GRAPHICS[C.Boss], (400, 300))

    def move(self):  # 定义怪物的随机移动，0，1，2，3代表四个斜方向的运动
        if self.state == 0:
            self.rect[0] += self.step
            self.rect[1] += self.step
        elif self.state == 1:
            self.rect[0] += self.step
            self.rect[1] += - self.step
        elif self.state == 2:
            self.rect[0] += - self.step
            self.rect[1] += self.step
        elif self.state == 3:
            self.rect[0] += - self.step
            self.rect[1] += - self.step
        # 碰到边界转向
        if self.rect[0] < 25:
            self.state = random.randint(0, 1)
        elif self.rect[0] > 1150:
            self.state = random.randint(2, 3)
        if self.rect[1] < 25:
            if random.randint(0, 1):
                self.state = 0
            else:
                self.state = 2
        elif self.rect[1] > 800:
            if random.randint(0, 1):
                self.state = 1
            else:
                self.state = 3