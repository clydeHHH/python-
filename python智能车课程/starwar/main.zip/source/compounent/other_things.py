# 道具（能量等）  残核（撞击掉生命值）
import random

import source.constant as constant
import source.states.main_menu as menu
import source.tools
import source.compounent.player as player

import pygame
import os
from PIL import Image
from pygame.sprite import Sprite


def _img(path, name, num_img) -> object:   #处理stone  buff的图片。
    size = int(random.random() * 80 + 10)
    pic_num = name + str((int(random.random() * num_img + 1))) + '.png'
    img = pygame.image.load(os.path.join(path, pic_num))
    rect_x = random.random() * constant.SCREEN_W    #随机的位置
    rect_y = random.random() * constant.SCERRN_H

    img = pygame.transform.scale(img, (size, size))  #随机大小

    bk = menu.Mainmenu.get_(menu.Mainmenu(), 'background')
    bk.blit(img, (rect_x, rect_y))   #blit

    return img, img.get_rect()


class others(Sprite):
    def __init__(self, img, img_rect, stats=True):  # 图片左上角坐标，屏幕大小，对象（buff/stone）的状态
        Sprite.__init__(self)
        self.stats = stats

        self.image = img
        self.rect = img_rect


class stone(others):
    def __init__(self, img, img_rect, stats=True) :
        super().__init__(img, img_rect, stats=True)

        self.rect.center = (random.random() * constant.SCREEN_W, random.random() * constant.SCERRN_H)  # sprite的中心

    def debuffs(self):  # 获得debuff，损失能量之类的
        self.kill()


class buff(others):
    def __init__(self, img, img_rect, stats=True):
        super().__init__(img, img_rect, stats=True)

        self.rect.center = (random.random() * constant.SCREEN_W, random.random() * constant.SCERRN_H)  # sprite的中心

    def buffs(self):  # 获得buff
        self.kill()


def cre(type_):  # 创建sprite对象
    path, name, num_img = '', '', 0
    if type_ == 'stone':
        path, name, num_img = 'resources/stone', 'stone', 4
    elif type_ == 'buff':
        path, name, num_img = 'resources/buff', 'buff', 5
    img, img_rect = _img(path, name, num_img)

    if type_ == 'stone':
        stone_ = stone(img, img_rect)
        return stone_
    elif type_ == 'buff':
        buff_ = buff(img, img_rect)
        return buff_


def coll(a, b):  # a一般是stone/buff  b是player
    #    print(type(a),type(b))
    flag = pygame.sprite.collide_rect(a, b)
    if flag:  ##发生碰撞
        return True
    else:  # 未发生
        return False

'''
def run():
    stone__ = cre('stone')
    buff__ = cre('buff')
    player__ = player.Player('astro1')

    if coll(stone__, buff__) == 1:
        stone__.debuffs()

    elif coll(buff__, player__) == 1:
        buff__.buffs()
'''