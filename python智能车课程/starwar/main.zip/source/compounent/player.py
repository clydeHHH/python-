import pygame
from .. import constant as C
from .. import setup, tools


class Player(pygame.sprite.Sprite):
    def __init__(self, name):
        pygame.sprite.Sprite.__init__(self)
        self.name = name
        self.load_image()
        self.setup_states()
        self.setup_vel()
        self.setup_timers()
        self.rect = self.image.get_rect()
        self.Blood = 100
        self.Power = 0

    def load_image(self):  # 加载某一状态玩家图片  在一个列表中保存
        if self.name == 'astro1':
            self.image = pygame.transform.scale(tools.GRAPHICS[C.PLAYER], (100, 100))
        if self.name == 'astro2':
            self.image = pygame.transform.scale(tools.GRAPHICS[C.PLAYER2], (150, 150))
        '''playerlist=[[tools.GRAPHICS['astro1'],
                     tools.GRAPHICS['astro2'],
                     tools.GRAPHICS['astro3'],
                     tools.GRAPHICS['astro4']]]'''

    def setup_states(self):  # 玩家状态BUFF
        self.dead = False
        self.buff = False


    def setup_vel(self):  # 玩家速度
        self.x_vel = 0
        self.y_vel = 0
        self.x_ace = 0
        self.y_ace = 0

    def setup_timers(self):  # 记录某一状态的时间
        self.buff_time = 0

    def update(self, keys, a):  # 更新玩家的运动
        # self.x_vel=0
        # self.y_vel=0   若此二语句不执行则为太空状态
        if a == 'player1':
            if keys[pygame.K_RIGHT]:
                self.x_ace = -C.ACE
            if keys[pygame.K_LEFT]:
                self.x_ace = C.ACE
            if keys[pygame.K_UP]:
                self.y_ace = C.ACE
            if keys[pygame.K_DOWN]:
                self.y_ace = -C.ACE

        if a == 'player2':
            if keys[pygame.K_d]:
                self.x_ace = -C.ACE
            if keys[pygame.K_a]:
                self.x_ace = C.ACE
            if keys[pygame.K_w]:
                self.y_ace = C.ACE
            if keys[pygame.K_s]:
                self.y_ace = -C.ACE

    def get_(self, name):
        if name == 'rect':
            a = self.rect
            return a
        elif name == 'img':
            b = self.image
            return b

    def debuffs(self,surface):
        self.Blood -= 40

    def buffs(self,surface):
        self.Power += 2

    def die(self,surface):
        pass

