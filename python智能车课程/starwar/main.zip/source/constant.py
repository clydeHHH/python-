SCREEN_W,SCERRN_H=1200,900
SCREEN_SIZE=(SCREEN_W,SCERRN_H) #游戏界面大小
from source import tools

BGM='resources/music/faster.mp3'
BK1='bk-1'    #主菜单背景页面
CURSOR='earth'   #主菜单光标


PLAYER='astro2'  #玩家图片列表
PLAYER2='astro1'
E1='monster1'#敌人图片列表
E2='monster2'
E3='monster3'
Boss='BOSS'

ACE=0.05


FONT='Bell MT'
COLOUR=(225,225,225)  #字体类型与颜色

