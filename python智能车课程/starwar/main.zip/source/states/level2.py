# 有boss，能量物减少，
import random
import pygame
import  math
from source.states import main_menu
from .. import setup, tools, constant
from ..compounent import info,enemy
from source.compounent import player
import source.compounent.other_things

num = 1


def rand_rec():
    rect_x = random.random() * constant.SCREEN_W  # 随机的位置
    rect_y = random.random() * constant.SCERRN_H
    return rect_x, rect_y


def coll_(ls1, ls2, ls3, background):
    for i in ls1:
        for j in ls3:
            if pygame.sprite.collide_rect(i, j):
                i.debuffs(background)
                j.debuffs(background)
                ls1.remove(i)
                i.stats = False
    for i in ls2:
        for j in ls3:
            if pygame.sprite.collide_rect(i, j):
                i.buffs(background)
                j.buffs(background)
                ls2.remove(i)
                i.stats = False
    return ls1, ls2


class Leval2():
    def __init__(self):
        # self.setup_background()

        self.player2 = player.Player('astro2')
        self.player1 = player.Player('astro1')
        self.setup_player()
        self.setup_enemy()
        # self.setup_cursor()
        # self.setup_label()
        self.next = None
        self.finish = 'm'
        self.info = info.information('Level2')

        self.stone1 = source.compounent.other_things.cre('stone')
        self.stone2 = source.compounent.other_things.cre('stone')
        self.stone3 = source.compounent.other_things.cre('stone')
        self.stone4 = source.compounent.other_things.cre('stone')
        self.stone5 = source.compounent.other_things.cre('stone')

        self.ls1 = [self.stone1, self.stone2, self.stone3, self.stone4, self.stone5]

        for i in self.ls1:
            i.rect.x, i.rect.y = rand_rec()

        self.buff1 = source.compounent.other_things.cre('buff')
        self.buff1.rect.x, self.buff1.rect.y = rand_rec()
        self.buff2 = source.compounent.other_things.cre('buff')
        self.buff2.rect.x, self.buff2.rect.y = rand_rec()

        self.ls2 = [self.buff1, self.buff2]

        self.ls3 = [self.player1, self.player2]

    def setup_player(self):
        self.player1.rect.x, self.player1.rect.y = (constant.SCREEN_W / 800) * 100, (constant.SCREEN_W / 800) * 100
        self.player2.rect.x, self.player2.rect.y = (constant.SCREEN_W / 800) * 200, (constant.SCREEN_W / 800) * 200

    def setup_background(self, surface):
        global num
        if num < 40:
            self.background = tools.GRAPHICS['bk-{}'.format(num)]
            self.background = pygame.transform.scale(self.background,
                                                     ((constant.SCREEN_W / 800) * 800, (constant.SCREEN_W / 800) * 600))
            self.background_rect = self.background.get_rect()
            num = num + 1
        elif num == 40:
            num = 1
        surface.blit(self.background, self.background_rect)

    def setup_over(self,surface):#创建游戏结束的提示
        self.over = tools.GRAPHICS['GAMEOVER']
        self.over = pygame.transform.scale(self.over,((constant.SCREEN_W / 800) * 600, (constant.SCREEN_W / 800) * 240))
        self.over_rect = self.over.get_rect()
        surface.blit(self.over,(150,315))

    def setup_enemy(self):#创建敌人
        self.enemy1=enemy.Enemy('E1')
        self.enemy2=enemy.Enemy('E2')
        self.enemy3=enemy.Enemy('E3')
        self.Boss=enemy.Enemy('Boss')

    def show_enemy(self,surface):#显示敌人
       self.setup_background(surface)
       surface.blit(self.enemy1.image,self.enemy1.rect)
       surface.blit(self.enemy2.image,self.enemy2.rect)
       surface.blit(self.enemy3.image,self.enemy3.rect)
       surface.blit(self.Boss.image,self.Boss.rect)

    def enemy_move(self):#敌人移动
        self.enemy1.move()
        self.enemy2.move()
        self.enemy3.move()
        self.Boss.move()

    def collide(self):#判断玩家与敌人是否发生碰撞
        if math.sqrt((self.player1.rect[0]-self.enemy1.rect[0])**2+(self.player1.rect[1]-self.enemy1.rect[1])**2)<50:
            return True
        elif math.sqrt((self.player1.rect[0]-self.enemy2.rect[0])**2+(self.player1.rect[1]-self.enemy2.rect[1])**2)<50:
            return True
        elif math.sqrt((self.player1.rect[0]-self.enemy3.rect[0])**2+(self.player1.rect[1]-self.enemy3.rect[1])**2)<50:
            return True
        elif math.sqrt((self.player1.rect[0]-self.Boss.rect[0])**2+(self.player1.rect[1]-self.Boss.rect[1])**2)<100:
            return True


    def update(self, surface, keys, state):
        self.setup_background(surface)
        #self.info.update()
        self.info.draw(surface)
        if self.collide():#发生碰撞则游戏结束
                self.setup_over(surface)
        else:#显示敌人的随机移动
            self.enemy_move()
            self.show_enemy(surface)
        if state == '1P':
            self.finish = '1'
            surface.blit(self.player1.image, self.player1.rect)
            self.player1.update(keys, 'player1')
            self.update_pos(self.player1)
        if state == '2P':
            self.finish = '2'
            surface.blit(self.player1.image, self.player1.rect)
            self.player1.update(keys, 'player1')
            self.update_pos(self.player1)
            surface.blit(self.player2.image, self.player2.rect)
            self.player2.update(keys, 'player2')
            self.update_pos(self.player2)

        for i in self.ls1:
            if i.stats:
                surface.blit(i.image, i.rect)

        for i in self.ls2:
            if i.stats:
                surface.blit(i.image, i.rect)

        self.ls1, self.ls2 = coll_(self.ls1, self.ls2, self.ls3, self.background)

        if self.player1.Blood < 0:
            self.player1.die(self.background)
        if self.player2.Blood < 0:
            self.player2.die(self.background)

        if self.player1.Power + self.player2.Power > 3:
            #到 level2 ？
            pass


        if keys[pygame.K_ESCAPE]:
            self.finish = 'return'

    def update_pos(self, a):
        a.x_vel += a.x_ace
        a.y_vel += a.y_ace
        a.rect.x += a.x_vel
        a.rect.y += a.y_vel

    def draw(self):
        pass
