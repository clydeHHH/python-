import pygame
from .. import setup, tools, constant
from ..compounent import info


# 菜单类
class Mainmenu():
    def __init__(self):

        self.setup_background()
        self.setup_player()
        self.setup_cursor()
        # self.setup_label()
        # 引入主菜单这一state所需要的文字信息
        self.info = info.information('Mainmenu')
        # false表示menu状态未完结
        self.finish = False
        self.next = 'load'
        self.cursor.state = '1P'


    def setup_background(self):
        self.background = tools.GRAPHICS[constant.BK1]
        self.background = pygame.transform.scale(self.background, constant.SCREEN_SIZE)
        self.background_rect = self.background.get_rect()

    '''def setup_label(self):
        self.label=tools.GRAPHICS['label']
        self.label = pygame.transform.scale(self.label, ((constant.SCREEN_W/800)*400,(constant.SCREEN_W/800)*100))
        self.label_rect = self.label.get_rect()'''

    def setup_player(self) :
        self.player = tools.GRAPHICS[constant.PLAYER]
        self.player = pygame.transform.scale(self.player,
                                             ((constant.SCREEN_W / 800) * 300, (constant.SCREEN_W / 800) * 300))

    def setup_cursor(self):
        self.cursor = pygame.sprite.Sprite()
        self.cursor.image = pygame.transform.scale(tools.GRAPHICS[constant.CURSOR],
                                                   ((constant.SCREEN_W / 800) * 30, (constant.SCREEN_W / 800) * 30))
        rect = self.cursor.image.get_rect()
        rect.x, rect.y = ((constant.SCREEN_W / 800) * 320, (constant.SCREEN_W / 800) * 240)
        self.cursor.rect = rect

    def update_cursor(self, keys):
        if keys[pygame.K_UP]:
            self.cursor.rect.y = (constant.SCREEN_W / 800) * 240
            self.cursor.state = '1P'
        elif keys[pygame.K_DOWN]:
            self.cursor.rect.y = (constant.SCREEN_W / 800) * 300
            self.cursor.state = '2P'
        elif keys[pygame.K_RETURN]:  # 控制进入下一个state
            if self.cursor.state == '1P':
                self.finish = '1P'
            elif self.cursor.state == '2P':
                self.finish = '2P'
            elif self.cursor.state == '3P':
                self.finish = True

    def update(self, surface, keys):  # surface来自tools调用时传入的screen
        surface.blit(self.background, self.background_rect)  # 背景
        surface.blit(self.player, ((constant.SCREEN_W / 800) * 100, (constant.SCREEN_W / 800) * 200))  # 人物
        # surface.blit(self.label, (200,50))  #标题
        self.update_cursor(keys)
        surface.blit(self.cursor.image, self.cursor.rect)  # 光标
        # 文字信息
#        self.info.update()
        self.info.draw(surface)

    def get_(self, name):
        if name == 'player_rec':
            return self.player.get_rect()
        elif name == 'background':
            return self.background

