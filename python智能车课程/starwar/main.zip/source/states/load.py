import pygame
from .. import setup,tools,constant
from ..compounent import  info


class Load():
    def __init__(self):
        self.setup_background()
        #self.setup_player()
        #self.setup_cursor()
        self.setup_label()
        self.info = info.information('Load')
        self.next='level'
        self.timer=0
        self.finish='m'


    def setup_background(self):
        self.background = tools.GRAPHICS[constant.BK1]
        self.background = pygame.transform.scale(self.background, ((constant.SCREEN_W/800)*800,(constant.SCREEN_W/800)* 600))
        self.background_rect = self.background.get_rect()

    def setup_label(self):
        pass


    def update(self,surface,keys,state):
        surface.blit(self.background,self.background_rect) #背景
#        self.info.update()
        self.info.draw(surface)
        if state=='1P':
            self.finish = '10'
            if self.timer==0:
                self.timer=pygame.time.get_ticks()
            elif pygame.time.get_ticks()-self.timer>=1000:
                self.finish='1P'
        elif state=='2P':
            self.finish = '20'
            if self.timer==0:
                self.timer=pygame.time.get_ticks()
            elif pygame.time.get_ticks()-self.timer>=1000:
                self.finish='2P'




    def draw(self):
        pass