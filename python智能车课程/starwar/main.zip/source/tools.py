import pygame
import random
import os
from PIL import Image
from source.states import main_menu, load, level, level2
from source import constant as C


# 初始数据文件夹path，将其修改后放入文件夹路径path2,最后将其加载
def load_graphics(path, path2, accept=('.png', '.jpg', '.bmp', '.jpeg', '.gif')):
    graphics = {}
    # 改变大小
    for pic in os.listdir(path):
        name, ext = os.path.splitext(pic)
        if ext in accept:
            img_path = Image.open(path + '/{}'.format(pic))
            # img_size=img_path.resize((1280,1280))
            try:
                img_path.save(path2 + '/{}'.format(pic))
            # print('保存成功')
            except:
                print('保存失败')
    for pic in os.listdir(path2):
        name, ext = os.path.splitext(pic)
        img = pygame.image.load(os.path.join(path2, pic))
        graphics[name] = img
    return graphics


# 得到的加载后的图片，用   GRAPHICS()  得到
GRAPHICS = load_graphics('resources/graphics1', 'resources/graphics2')


# 运行游戏并更新游戏画面
class GAME():
    def __init__(self, state_dic, state_start):
        self.screen = pygame.display.get_surface()
        self.clock = pygame.time.Clock()
        self.keys = pygame.key.get_pressed()
        self.state_dic = state_dic
        self.state = self.state_dic[state_start]
        pygame.mixer.music.load(C.BGM)
        pygame.mixer.music.play(-1, 0)
        pygame.display.set_caption('SPACE WAR')
        pygame.display.set_icon(GRAPHICS['astro2'])

    def update(self):
        if self.state.finish == False:
            self.state.update(self.screen, self.keys)
        elif self.state.finish == '1P':
            self.state = self.state_dic[self.state.next]
            self.state.update(self.screen, self.keys, '1P')
        elif self.state.finish == '2P':
            self.state = self.state_dic[self.state.next]
            self.state.update(self.screen, self.keys, '2P')
        elif self.state.finish == '10':
            self.state.update(self.screen, self.keys, '1P')
        elif self.state.finish == '20':
            self.state.update(self.screen, self.keys, '2P')
        elif self.state.finish == '1':
            self.state.update(self.screen, self.keys, '1P')
        elif self.state.finish == '2':
            self.state.update(self.screen, self.keys, '2P')
        elif self.state.finish == '1PP':
            self.state = self.state_dic[self.state.next]
            self.state.update(self.screen, self.keys, '1P')
        elif self.state.finish == '2PP':
            self.state = self.state_dic[self.state.next]
            self.state.update(self.screen, self.keys, '2P')



        elif self.state.finish == 'return':
            self.state = self.state_dic['main_menu']
            self.state.finish = False

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.display.quit()
                elif event.type == pygame.KEYDOWN:
                    self.keys = pygame.key.get_pressed()
                elif event.type == pygame.KEYUP:
                    self.keys = pygame.key.get_pressed()
            self.update()  # 将得到的screen传给update()形参surface
            pygame.display.update()
            self.clock.tick(60)
