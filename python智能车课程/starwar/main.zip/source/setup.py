import pygame
from source import constant

#游戏初始化并启动界面
pygame.init()
pygame.mixer.init()
pygame.display.set_mode((constant.SCREEN_SIZE))